package Data_clumps;

public class problem {
    void colorize(int red, int green, int blue){}

}
