package Data_clumps;

public class Solution {
    int red;
    int green;
    int blue;

    void colorize(){

    }
}
