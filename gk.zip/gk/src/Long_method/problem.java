package Long_method;

public class problem {
    void printOwing() {
        printBanner();

        //print details
        String name = null;
        System.out.println("name: " + name);
        System.out.println("amount: " + getOutstanding());
    }

    private String getOutstanding() {
        return null;
    }

    private void printBanner() {
    }

}
